Spacecamp
================================

Spacecamp is a browser extension that adds extra project management power to your basecamp project portal(s). It allows users to do scrum like estimations on theire Basecamp 3 todo items and lists (screenshot 1). And adds labels and time tracking (via timechimp) to your todo items (screenshot 2 and 3). 

You can find the source on Github; https://github.com/ismarvelous/spacecamp. There is also a v0.1 that only has support for Basecamp 2. If you don't see the calculation press - CRTL-F5.