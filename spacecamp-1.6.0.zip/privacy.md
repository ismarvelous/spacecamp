Privacy Policy Spacecamp browser plugin.

Your privacy is important to us. It is Marvelous' policy to respect your privacy. We do not ask or collect any personal while using this plugin.

We don’t share any personally identifying information publicly or with third-parties.

Our addon is executed on external sites (basecamp and timechimp) that are not operated by us. Please be aware that we have no control over the content and practices of these sites, and cannot accept responsibility or liability for their respective privacy policies.

You are free to refuse our request for your personal information, with the understanding that we may be unable to provide you with some of your desired services.

Your continued use of our plugin will be regarded as acceptance of our practices around privacy and personal information. If you have any questions about how we handle user data and personal information, feel free to contact us.

This policy is effective as of 27 August 2020.